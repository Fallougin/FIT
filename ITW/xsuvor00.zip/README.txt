https://drive.google.com/drive/folders/15Z2YFPGvBFg-UTQCY4OvkJBvSqfvLMSA


Can you please download folder from that link and add folder img to ZIP

Můžete si prosím stáhnout složku z tohoto odkazu a přidat složku img do ZIP

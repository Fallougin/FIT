var id = 1;
ID_Slides(id);

function Slide(n) 
{
    ID_Slides(id = n);
}

function ID_Slides(n) {
    var i = 0;
    var slide = document.getElementsByClassName("Slide");
    var dots = document.getElementsByClassName("dot");

    if (n > slide.length) 
    {
        id = 1;
    }

    if (n < 1) 
    {
        id = slide.length;
    }

    for (i = 0; i < slide.length; i++) 
    {
        slide[i].style.display = "none";
    }

    for (i = 0; i < dots.length; i++) 
    {
        dots[i].className = dots[i].className.replace("active", " ");
    }
    
    slide[id-1].style.display = "block";
    dots[id-1].className += " active";
}




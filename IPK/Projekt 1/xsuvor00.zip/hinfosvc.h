#include <stdlib.h>


char* generate_response();

char* generate_not_found();

char* generate_200_ok();

char* get_hostname();
